# Goals

This Git repository contains tools used by the GEL team to build and maintain the their RACE collection.

## Collections Tracking

[Collections Tracking](doc/collections.tracking.md)

## RACE Collection

Book the [7-machine blank collection](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=45441&imageKind=C&comment=Viya33build&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=2&admin=yes) with VIP tunnel

## Structure

- playbooks:
- inventories:
- doc





## Git reminders

### Git global setup

``` bash
git config --global user.name "Erwan Granger"
git config --global user.email "erwan.granger@sas.com"
```

### Create a new repository

``` bash
git clone https://gitlab.sas.com/GEL/ViyaRACEBuild.git
cd ViyaRACEBuild
touch README.md
git add README.md
git commit -m "add README"
git push -u origin master
```

### Existing folder

``` bash
cd existing_folder
git init
git remote add origin https://gitlab.sas.com/GEL/ViyaRACEBuild.git
git add .
git commit -m "Initial commit"
git push -u origin master
```

### Existing Git repository

``` bash
cd existing_repo
git remote add origin https://gitlab.sas.com/GEL/ViyaRACEBuild.git
git push -u origin --all
git push -u origin --tags
```
