#!/bin/bash
# past this onto the box.
# ideally in tmux

export rootfol=/mnt/c/Users/canepg/DOCUME~1/Cloud/
export ANSIBLEHOST=aznvir01004.race.sas.com
export ANSIBLEUSER=cloud-user
export SSHKEY=./cloud-user-key.pem
export SSHRUN="ssh -i $SSHKEY  $ANSIBLEUSER@$ANSIBLEHOST -t "
export workdir=/home/cloud-user/autodeploy

$SSHRUN "mkdir -p $workdir"

 echo "rsync the files up, from my workstation. "
 rsync -e "ssh -i $SSHKEY" --exclude='.git/' -avz $rootfol/VIYARA~1/ $ANSIBLEUSER@$ANSIBLEHOST:$workdir/ViyaRACEBuild/



$SSHRUN
sudo yum install -y tmux
tmux
cd autodeploy/ViyaRACEBuild/playbooks/

export INVENTORY=~/autodeploy/ViyaRACEBuild/inventories/aznvir.ini

if [ ! -f /etc/yum.repos.d/epel.repo ]; then \
         echo 'ansible install' ;
         sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm ;\
         sudo yum install -y python-pip gcc python-devel ;\
         sudo pip install --upgrade pip ; \
         sudo pip install 'ansible==2.3.2'; \
         fi ; \
ansible --version


#ansible test -m ping -i $INVENTORY


chmod 700 cloud-user-key.pem

ansible-playbook id.yml
ansible-playbook id.yml --limit test


ansible test -m file -a "path=/home/cloud-user/autodeploy state=directory"

#ansible si01 -m synchronize -a "src=$rootfol/VIYARA~1/ dest=$workdir/ViyaRACEBuild/ rsync_opts='--exclude=.git'"



ansible test -m yum -a "name=git state=present" -b

ansible test -m shell -a "cd ~/autodeploy ; GIT_REPO=https://github.com/sassoftware/virk.git ; BRANCH_TO_USE='viya-3.3' ; git clone $GIT_REPO --branch $BRANCH_TO_USE "




cat << 'EOF' > ./single.inventory.ini
deployTarget ansible_connection=local

[openldapserver]
deployTarget

[openldapclients]
deployTarget

[openldapall:children]
openldapserver
openldapclients

[sas-all:children]
openldapserver
openldapclients

EOF


cat << 'EOF' > ./coll.inventory.ini
sasviya01 ansible_ssh_host=sasviya01.race.sas.com
sasviya02 ansible_ssh_host=sasviya02.race.sas.com
sasviya03 ansible_ssh_host=sasviya03.race.sas.com
sascas01  ansible_ssh_host=sascas01.race.sas.com
sascas02  ansible_ssh_host=sascas02.race.sas.com
sascas03  ansible_ssh_host=sascas03.race.sas.com

[openldapserver]
sasviya01

[openldapclients]
sasviya01
sasviya02
sasviya03
sascas01
sascas02
sascas03


[openldapall:children]
openldapserver
openldapclients
[sas-all:children]
openldapserver
openldapclients

EOF


ansible-playbook -i ~/autodeploy/single.inventory.ini \
    virk/playbooks/pre-install-playbook/viya_pre_install_playbook.yml \
    --skip-tags skipmemfail,skipcoresfail,skipstoragefail,skipnicssfail,bandwidth \
   -e 'use_pause=no' \
   -e '{"custom_group_list": { "group": "sas" , "gid":"10001" } }' \
   -e '{"custom_user_list": [ { "name": "cas" , "uid":"10002", "group":"sas" , "groups":"sas" } , { "name": "sas" , "uid":"10001", "group":"sas" , "groups":"sas" } ] }'


cd ~/autodeploy/OpenLDAP
ansible-playbook gel.openldapremove.yml  \
      -i $INVENTORY
ansible-playbook gel.openldapsetup.yml -e "OLCROOTPW=lnxsas"  -i $INVENTORY




cd ~/autodeploy
curl --insecure -o SAS_Viya_playbook.tgz  https://gelweb.race.sas.com/scripts/PSGEL109_001/SAS_Viya_playbook.tgz
tar -xf SAS_Viya_playbook.tgz
cd ~/autodeploy/sas_viya_playbook
ORDER=09LX96
curl --insecure -o repo_override.txt  https://gelweb.race.sas.com/mirror/$ORDER/repo_override.txt

#backup vars.yml and inventory.
cp vars.yml vars.yml.orig
cp inventory.ini inventory.ini.orig


cp ~/autodeploy/OpenLDAP/sitedefault.yml  ~/autodeploy/sas_viya_playbook/roles/consul/files/


cd ~/autodeploy/sas_viya_playbook/
#cp sample-inventories/inventory_local.ini inventory.ini
time ansible-playbook site.yml -e "@repo_override.txt" -i sample-inventories/inventory_local.ini
