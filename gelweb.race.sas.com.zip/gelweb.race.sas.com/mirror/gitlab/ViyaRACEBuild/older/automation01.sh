#!/bin/bash

## connect to a machine


export rootfol=/mnt/c/Users/canepg/DOCUME~1/Cloud/
export ANSIBLEHOST=pdcesx01166.race.sas.com
export ANSIBLEUSER=cloud-user
export SSHKEY=./cloud-user-key.pem
export SSHRUN="ssh -i $SSHKEY  $ANSIBLEUSER@$ANSIBLEHOST -t "
export workdir=/home/cloud-user/automation



ansible si01 -m file -a "path=$workdir state=directory"

ansible si01 -m synchronize -a "src=$rootfol/VIYARA~1/ dest=$workdir/ViyaRACEBuild/ rsync_opts='--exclude=.git'"

# - synchronize:
#     src: some/relative/path
#     dest: /some/absolute/path





# echo "rsync the files up, from my workstation. "
# echo "rsync ViyaRACEBuild folder" ; rsync -e "ssh -i $SSHKEY" --exclude='.git/' -avz $rootfol/VIYARA~1/ $ANSIBLEUSER@$ANSIBLEHOST:$workdir/ViyaRACEBuild/
#
# echo "rsync OpenLDAP folder"      ; rsync -e "ssh -i $SSHKEY" --exclude='.git/' -avz $rootfol/CloudUp/OpenLDAP/ $ANSIBLEUSER@$ANSIBLEHOST:$workdir/OpenLDAP/

#$SSHRUN ls -alR $workdir


# $SSHRUN "if [ ! -f /etc/yum.repos.d/epel.repo ]; then \
#          echo 'ansible install' ;
#          sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm ;\
#          sudo yum install -y python-pip gcc python-devel ;\
#          sudo pip install --upgrade pip ; \
#          sudo pip install 'ansible==2.3.2'; \
#          fi ; \
#          ansible --version "
#
# #$SSHRUN ansible --version
#
# echo "nothing"
# $SSHRUN 'ansible localhost -m yum -a "name=git state=present" -b \
#           cd ~/working \
#           GIT_REPO=https://github.com/erwangranger/virk.git \
#           BRANCH_TO_USE=newer33 \
#           git clone $GIT_REPO --branch $BRANCH_TO_USE '



#$SSHRUN "cd $workdir ; ansible-playbook generate.inventory.yml"

#$SSHRUN "cd $workdir ; ansible-playbook network.fix.yml --step "

#$SSHRUN "cd $workdir ; ansible-playbook time.fix.yml  --diff"

#$SSHRUN "cd $workdir ; ansible-playbook tunnelsetup.yml"
# $SSHRUN "cd $workdir ; ansible-playbook tunnelsetup.yml --tags hostlist,generatefiles"

#$SSHRUN "cd $workdir ; ansible ext -m shell -a 'grep \"ip tunnel\" /opt/RACE_Integration/VirtualTunnel ' "
#$SSHRUN "cd $workdir ; ansible ext -m shell -a 'grep \"192\" /opt/RACE_Integration/VirtualTunnel ' "
#$SSHRUN "cd $workdir ; ansible ext -m shell -a 'cat  /opt/RACE_Integration/VirtualTunnel ' "

# $SSHRUN "cd $workdir ; ansible-playbook coll.checks.yml "

#$SSHRUN "cd $workdir ; ansible-playbook cleanhosts.yml "
