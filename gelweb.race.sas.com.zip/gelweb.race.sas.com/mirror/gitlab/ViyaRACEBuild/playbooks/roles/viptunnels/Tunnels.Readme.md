# Tunnels stand-alone playbook

This playbook is used to build a set of VIP tunnels within a RACE Collection.
The reason for this tunnel is that for Viya, we need to have static IPs.
Our VIPs are going to be static.

# Limitations due to Erwan's low coding skills

* Your servers have to have a hostname of either
  * sasviyaNN
  * sascasNN
  * sascdhNN
  * sashdpNN
* NN has to be exactly 2 digits

# How to use

Download the playbook (tunnels) to your ansible controller.

1. Download the ViyaRACEBuild content onto your ansible controller
```
wget --no-parent --no-check-certificate -r https://gelweb.race.sas.com/mirror/gitlab/ViyaRACEBuild/
mv gelweb.race.sas.com/mirror/gitlab/ViyaRACEBuild/ ViyaRACEBuild
rm -rf gelweb.race.sas.com
find ViyaRACEBuild -type f  -name "index.html*" -exec rm -f {} \;
```

1. Move to the "tunnels role"

```
cd /root/tunnels
```
1. First, you need to have an inventory generated for you. (ignore the warning about missing inventory):
```
ansible-playbook generate.inventory.yml
```
1. Now, you can execute the tunnel setup playbook
```
ansible-playbook network.fix.yml
```
1. Now, you can execute the tunnel setup playbook
```
ansible-playbook tunnelsetup.yml
```
