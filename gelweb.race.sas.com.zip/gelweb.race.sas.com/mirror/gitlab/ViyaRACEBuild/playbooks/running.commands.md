# commands

- move into the right folder
```
cd playbooks
```

- test ansible ping
```
ansible collE -m ping
ansible collW -m ping
```

1. wipe clean
```
ansible-playbook 00-wipeclean.yml --step --limit W_intviya01
ansible-playbook 00-wipeclean.yml  --limit Ogreen_intviya01
```

1. keys setup
```
ansible-playbook 01-keysetup.yml --ask-pass --limit collZ,collBlue,collGreen
```

1. Prep and deploy
```
ansible-playbook 03-prep.and.deploy.yml  --step --limit collW -e "ordernum=09LFK4"


ansible-playbook 03-prep.and.deploy.yml  --step --limit collGreen -e "ordernum=09LHP3" --tags       epel,ansible,mirror,push,openldap,readiness,build

```

1. install guac
```
ansible-playbook setup.guacamole.yml   
```
