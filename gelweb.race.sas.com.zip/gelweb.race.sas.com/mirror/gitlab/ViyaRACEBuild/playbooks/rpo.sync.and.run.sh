#!/bin/bash
# export rootfol=/mnt/c/Users/canepg/DOCUME~1/Cloud/
export rootfol=/mnt/c/_RPO/SAS/GEL/CollectionAutomation/ViyaRACEBuild
export ANSIBLEHOST=mirrorcreator.openstack.sas.com
export ANSIBLEUSER=frarpo

#ssh-copy-id -i ~/.ssh/id_rsa.pub  $ANSIBLEUSER@$ANSIBLEHOST
export SSHRUN="ssh  $ANSIBLEUSER@$ANSIBLEHOST -t "

# echo "rsync the files up"
rsync -e "ssh " --exclude='.git/' -avz $rootfol $ANSIBLEUSER@$ANSIBLEHOST:/home/$ANSIBLEUSER/
$SSHRUN "cd ViyaRACEBuild/playbooks ; ansible lin -m ping ; ansible lin -m shell -a 'hostname'"
#$SSHRUN "cd ViyaRACEBuild/playbooks ; ansible-playbook psgel144_build_blank.yml --step"
#  $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible-playbook psgel144_build_blank.yml --tags ansiblesetup"
# $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible-playbook psgel144_build_deployed.yml --tags runvirk"
# $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible-playbook psgel144_build_deployed.yml --tags runopenldap"
#   $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible-playbook psgel144_build_deployed.yml --skip-tags runit"
# $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible-playbook psgel144_build_blank.yml -i ../inventories/azntest.ini"
#  $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible  all -m setup | grep -i centos "
#  $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible-playbook test.yml -i ../inventories/azntest.ini "
# $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible-playbook test.yml  "
#  $SSHRUN "cd ViyaRACEBuild/playbooks ; ansible all -m setup | grep -i hat "
