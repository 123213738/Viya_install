# Base Collections

## Base collection on VMWare

* Collection ID:
  * 86916
* links:
  * [book for 1 day](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=86916&imageKind=C&comment=BaseCollection&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=1&admin=yes)
  * [book for 5 day](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=86916&imageKind=C&comment=BaseCollection&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=5&admin=yes)
* Details:

| id       | OS           | alias                       |  user      | pass      |
|----------|--------------|-----------------------------|------------|-----------| 
|  787299  | CentOS 7.5   |  sasviya01.race.sas.com     | cloud-user | Orion123  | 
|  787299  | CentOS 7.5   |  sasviya02.race.sas.com     | cloud-user | Orion123  |
|  787299  | CentOS 7.5   |  sasviya03.race.sas.com     | cloud-user | Orion123  |
|  787299  | CentOS 7.5   |  sascas01.race.sas.com      | cloud-user | Orion123  |
|  787299  | CentOS 7.5   |  sascas02.race.sas.com      | cloud-user | Orion123  |
|  787299  | CentOS 7.5   |  sascas03.race.sas.com      | cloud-user | Orion123  |
|  786448  | Windows 2016 |  sasclient.race.sas.com     | student    | Metadata0 |

## Base Image on AWS

* 787633 (Centos 7.5)

## Raphael collection on AWS

* Collection ID:
  * BASE : 88465
  * BLANK (ready for deployment workshop) : 88468
* links:
  * [book for 1 day](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=88468&imageKind=C&comment=BaseCollection&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=1&admin=yes)
  * [book for 5 day](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=88468&imageKind=C&comment=BaseCollection&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=5&admin=yes)

* Details of 88468:

| id       | OS           | alias                       |  user      | pass      |I type              |
|----------|--------------|-----------------------------|------------|-----------|--------------------| 
|  797795  | CentOS 7.5   |  sasviya01.race.sas.com     | cloud-user | Orion123  | I3 2XLarge 8c 61GB |
|  797796  | CentOS 7.5   |  sasviya02.race.sas.com     | cloud-user | Orion123  | I3 2XLarge 8c 61GB |
|  797797  | CentOS 7.5   |  sasviya03.race.sas.com     | cloud-user | Orion123  | I3 2XLarge 8c 61GB |
|  797798  | CentOS 7.5   |  sascas01.race.sas.com      | cloud-user | Orion123  | I3 Large 2c 15GB   |
|  797799  | CentOS 7.5   |  sascas02.race.sas.com      | cloud-user | Orion123  | I3 Large 2c 15GB   |
|  797800  | CentOS 7.5   |  sascas03.race.sas.com      | cloud-user | Orion123  | I3 Large 2c 15GB   |

## Marks collection on RACE EXNET

* Collection ID:
  * BASE : 88465
  * BLANK (ready for deployment workshop) : 88468
* links:
  * [book for 1 day](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=88468&imageKind=C&comment=BaseCollection&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=1&admin=yes)
  * [book for 5 day](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=88468&imageKind=C&comment=BaseCollection&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=5&admin=yes)

* Details of 88468:

| id       | OS           | alias                       |  user      | pass      |I type              |
|----------|--------------|-----------------------------|------------|-----------|--------------------| 
|  797795  | CentOS 7.5   |  sasviya01.race.sas.com     | cloud-user | Orion123  | I3 2XLarge 8c 61GB |
|  797796  | CentOS 7.5   |  sasviya02.race.sas.com     | cloud-user | Orion123  | I3 2XLarge 8c 61GB |
|  797797  | CentOS 7.5   |  sasviya03.race.sas.com     | cloud-user | Orion123  | I3 2XLarge 8c 61GB |
|  797798  | CentOS 7.5   |  sascas01.race.sas.com      | cloud-user | Orion123  | I3 Large 2c 15GB   |
|  797799  | CentOS 7.5   |  sascas02.race.sas.com      | cloud-user | Orion123  | I3 Large 2c 15GB   |
|  797800  | CentOS 7.5   |  sascas03.race.sas.com      | cloud-user | Orion123  | I3 Large 2c 15GB   |

