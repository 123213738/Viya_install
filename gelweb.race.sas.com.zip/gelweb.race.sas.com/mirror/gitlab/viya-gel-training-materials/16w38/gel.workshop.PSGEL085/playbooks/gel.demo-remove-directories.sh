sed -i -e "s/present: yes/present: no/g" ./gel.demo-directory-list.yml
ansible-playbook gel.demo-directories.yml "$@"
