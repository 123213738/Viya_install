#!/bin/sh
#need ksh, and the automount stuff to source homedirs / user shells
yum install -y ksh sssd autofs nfs-utils nfs-utils-lib
chkconfig nfs on
chkconfig sssd on
chkconfig autofs on
chkconfig rpcbind on
service autofs start
service rpcbind start
service nfs start

cat <<-'EOF' >> /etc/ssl/certs/sascaroot.pem

-----BEGIN CERTIFICATE-----
MIIFcDCCA1igAwIBAgIQbm98nzAcbppBopc/FBbW/zANBgkqhkiG9w0BAQUFADBA
MRMwEQYKCZImiZPyLGQBGRYDY29tMRMwEQYKCZImiZPyLGQBGRYDU0FTMRQwEgYD
VQQDEwtTQVMgUm9vdCBDQTAeFw0wNzExMjYxNjA0MDlaFw0yNzExMjYxNjA4NDJa
MEAxEzARBgoJkiaJk/IsZAEZFgNjb20xEzARBgoJkiaJk/IsZAEZFgNTQVMxFDAS
BgNVBAMTC1NBUyBSb290IENBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
AgEAt45r6l9KNXbVAyXa/oq1hSSZlPDZdx7ZWQ16s3ztFMamYVq6y6uCfTqx9HNB
2tJWPDM7/jI/Ny5lyq3Zwc9nxXSjL9dtJvOQ7J0MVBmG99n9BvWwrYqH7KXAYugb
Qw2FuGu8ILU7bA2aSFbWUQ7OjpaLLlNuardFQrlEXIkHQr72arsSMOK39RzP8aRS
/mxCHgQsOGTqB5TBNBOETBSpggEpmvMmnfXkSZhuOm8/zx0lvnJ3nYwqUPtNOaC6
BFLivKTzBX2iuGnd+Gr0+j4vgIvtucxaOO+sPOvAYrw2BmywnxOcjqB0aOHRQonA
szHj6Ekfi6KzScYbgwsPwk9G7O0HbTYTEk3Wnwvg/V8KuqRC01IAa173DiegU4NT
0CQnguu3YBv0Qdg5+po2hLTgEDfgV7psB/WHPrcyLIeSzDs851dfTmPRFKDkgSTZ
uwoBKL8eEA5joCLcsKoJNbdXgGQfRGNFxhXUStolXTQQBKeBdMmaSYK15sxZ7fHs
81sjyiPss93sqH/sfGr+WCiLnvXuSbKX6h+snVSRBNhlGshSKr32XE/HxvVcr5yj
haZQ2yOplNtrvr99ZFbD0cjF+QN9gYG5p1RDv9Z5wNmJ1cVLGHIMz4LssHc8626H
Ei8abVmeQdeFva6qkogEU031JFGlT1s+CiytWF3W3qvz6NkCAwEAAaNmMGQwEwYJ
KwYBBAGCNxQCBAYeBABDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8w
HQYDVR0OBBYEFCD4poJrlv6SyHGFnK+Lc8eLLOvmMBAGCSsGAQQBgjcVAQQDAgEA
MA0GCSqGSIb3DQEBBQUAA4ICAQAXG6yY+ETDxckhcbPpegmsOXQrt+VZFXd2ANq2
0tPhUCLqG1VEQJumbIH/0Cgdz/p+MNOyimM3J6ZWOnKA7kzB/lGEG80p30gVu3LY
sa+R3aErY8lEz+8QNnDNBkVZ3WpekkgmqxvSygq6fNOMI+xDdFScXW21IWU870aw
7f5GZKqJRA9nv87mWf+vj3GDDJQfEB/QkGRU19d/YPTm3Bktk+B0JT5h/TvSVigY
i1DCB0unwb+2hIoDhYfy5OyX4hdMKEGtwFlINpQ/x2M/+51DAFxugsUzjwn2O0yY
ZlBClfLLfr7QgTVQtiBRelgfZb9Pzu20/Ym1i7ljGaa+DnDnO+3zBeEygzl3pHbm
6vENkrOxiXEgF6oDdiOUgroXCVuo6WXWGg44BjQpan99LxgqJQdoj2c9ou4wTJc4
RZX+eGmSDB5pEGkrrvudaq/GvnfgmRxedQA1Caeff8zgs7tnXLCGpyu0o1tHHgsZ
0B4flzTWc7LAwtZkebrib3HjN6PboLBahTbkDNYeA3RK+MjyLLoyShwbI/WlVlQV
2Ry5SstemXw1Xk4scAH2a4riame5P6TJhD8KDMkc0BiGFvBJQUIcvP5ESnCN/VI0
O238yjiYEIJmuLYgp+hD/ZTNdGB88qJ/yeSHnOMa4/ybFYFFu7/knS/1YX1kid0E
JV3fkA==
-----END CERTIFICATE-----
EOF

cat <<-'EOF' >> /etc/sssd/sssd.conf

[sssd]
config_file_version = 2
services = nss,pam
sbus_timeout = 30
domains = SAS.COM

[nss]
filter_users = root
filter_groups = root

[domain/SAS.COM]
enumerate = false
cache_credentials = true

id_provider = ldap
auth_provider = ldap
chpass_provider = ldap
autofs_provider = none

ldap_uri = ldap://ldap.fyi.sas.com:3268
ldap_search_base = dc=SAS,dc=com
ldap_default_bind_dn = CN=[MDR] Anonymous LDAP Query,CN=Users,DC=na,DC=SAS,DC=com
ldap_default_authtok_type = password
ldap_default_authtok = LD@Pid

ldap_schema = rfc2307bis

ldap_user_object_class = user
ldap_user_home_directory = unixHomeDirectory
ldap_user_principal = sAMAccountName
ldap_user_name = sAMAccountName
ldap_group_object_class = group
ldap_access_order = expire
ldap_account_expire_policy = ad
ldap_force_upper_case_realm = true
ldap_disable_referrals = true

ldap_user_search_base = DC=SAS,DC=com?subtree?(|(memberOf=CN=[POS] Domestic Development Users,OU=Groups,OU=RDC,OU=US,OU=Servers,DC=na,DC=SAS,DC=com)(sAMAccountName=hadoop)(sAMAccountName=hdfs)(sAMAccountName=zookeeper)(sAMAccountName=httpfs)(sAMAccountName=mapred)(sAMAccountName=sqoop)(sAMAccountName=yarn)(sAMAccountName=hive)(sAMAccountName=sqoop2)(sAMAccountName=oozie)(sAMAccountName=hbase)(sAMAccountName=hue)(sAMAccountName=cloudera-scm)(sAMAccountName=impala))
ldap_id_use_start_tls = true
ldap_tls_reqcert = demand
ldap_tls_cacert = /etc/ssl/certs/sascaroot.pem

#ldap_groups_use_matching_rule_in_chain = true
#ldap_initgroups_use_matching_rule_in_chain = true
#ldap_use_tokengroups = true

EOF

chmod 600 /etc/sssd/sssd.conf

authconfig --passalgo=sha512 --enablesssd --enablesssdauth --enablemkhomedir --update
service sssd restart
#by default, automounter loads into /net, add the symlink to take care of home directories
ln -s /net /r
#free bsd bash is in a different place
ln -s /bin/bash /usr/local/bin/bash

