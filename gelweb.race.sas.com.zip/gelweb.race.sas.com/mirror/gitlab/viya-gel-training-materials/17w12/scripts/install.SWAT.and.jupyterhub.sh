#!/bin/bash

# to be converted to playbook
sudo yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm -y
sudo yum install python-pip -y
sudo yum install bzip2 -y

cd /opt
sudo curl -O https://repo.continuum.io/archive/Anaconda3-4.4.0-Linux-x86_64.sh

sudo bash Anaconda3-4.4.0-Linux-x86_64.sh -b -p  /opt/anaconda3

## Install python-swat
sudo /opt/anaconda3/bin/pip install https://github.com/sassoftware/python-swat/releases/download/v1.2.0/python-swat-1.2.0-linux64.tar.gz
## upgrade pip
sudo /opt/anaconda3/bin/pip install --upgrade pip

# install nodejs
sudo yum install nodejs -y
## installing nodesource
sudo curl --silent --location https://rpm.nodesource.com/setup_4.x | sudo bash -
## installing configurable-http-proxy
sudo npm install -g configurable-http-proxy
## Install jupyterhub
sudo /opt/anaconda3/bin/pip install jupyterhub


#create a config file
sudo mkdir /opt/anaconda3/etc/jupyterhub
sudo rm -f /opt/anaconda3/etc/jupyterhub/jupyterhub_config.py
sudo /opt/anaconda3/bin/jupyterhub --generate-config -f /opt/anaconda3/etc/jupyterhub/jupyterhub_config.py

# append some lines to the config file

sudo bash -c "cat << EOF >> /opt/anaconda3/etc/jupyterhub/jupyterhub_config.py
#c.JupyterHub.confirm_no_ssl = True
c.JupyterHub.cookie_secret_file = '/opt/anaconda3/var/cookie_secret'
c.JupyterHub.pid_file = '/opt/anaconda3/var/jupyterhub.pid'
c.JupyterHub.cleanup_servers = True
c.JupyterHub.cleanup_proxy = True
## this is sometimes required.
c.Spawner.cmd = ['/opt/anaconda3/bin/jupyterhub-singleuser']
EOF"

echo 'export PATH="/opt/anaconda3/bin:$PATH"' >> ~/.bashrc
. ~/.bashrc

#start it up
sudo nohup /opt/anaconda3/bin/jupyterhub -f /opt/anaconda3/etc/jupyterhub/jupyterhub_config.py &


# create a python test program
cat << EOF >> ~/castest.py
import swat
conn = swat.CAS('localhost',5570, 'sasdemo01', 'lnxsas', caslib="casuser")
# Get the csv file from SAS support documentation
castbl = conn.read_csv('http://support.sas.com/documentation/onlinedoc/viya/exampledatasets/hmeq.csv', casout = 'hmeq')
print(conn)
out = conn.serverstatus()
print(out)
conn.close()
EOF

# execute the test program
/opt/anaconda3/bin/python ~/castest.py


# run the same code in your jupyter notebook. 
