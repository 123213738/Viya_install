# Intro
These instructions come in two flavors: 
- Hard-mode 
- Easy-Mode

If you're just starting out, you'll want to scroll down to the Easy-Mode instructions, which will keep you on the happy path, and hold your hand while you go through a happy, successful deployment. 

If you want to test what you're made of, Hard-Mode is for you. The instructions are minimal, some things may or may not work well. It migh be more frustrating, but you'll also learn a whole lot more. 



## Hard Mode

### book the race collection

### listen to the intro while you wait

### install MobaXterm if you don't have it

### Look at the Sample SOE

### Connect to the environment


### Install Ansible


### Download the Default order Playbook




## Easy mode

### book the blank race collection

Before getting started, you should reserve your hardware. This can be done using the link below. 

[Book the blank collection for 2 days](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=27573&imageKind=C&comment=BLANK%20RHEL%207.1%20Servers%20&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=2)

If you are not allowed to reserve using that link, then send an e-mail to:
```
dlistadmin@wnt.sas.com
```
with subject:
```
Subscribe STICEXNETUsers
```
to join the STICExnetUsers group. 

You will be notified via email of the creation of the account. Your account should be created and ready for use within 1 hour. When you receive the confirmation e-mail, you should be able to book the collection then. 


### Introduction
While you are waiting for the Collection to start, you can watch this introduction video. 

PLACEHOLDER for video

### MobaXterm
If you do not have MobaXterm already installed on your workstation, you should get free evaluation version from [here](http://mobaxterm.mobatek.net/), and install it. 

If you don't have a Windows Workstation, you will need an alternative SSH client. 

### Look at the Sample SOE



### Connect to the environment
  ssh to first machine in list
  as cloud-user
  with the provided ssh key



### Install Ansible
```
# on RHEL 7, this should work:
sudo rpm -ivh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo yum install -y ansible

```

```
[cloud-user@pdcesx03025 ~]$ ansible --version
ansible 2.0.2.0
  config file = /etc/ansible/ansible.cfg
  configured module search path = Default w/o overrides
[cloud-user@pdcesx03025 ~]$
```



```
sudo yum install -y python-pip
sudo pip install --upgrade pip
sudo pip install ansible --upgrade
```

### Download viya ML w20 playbook
will come as a wget command from a central web server (like yumrepomirror)


```
tar -xvf sas-viya-deployment.tgz
cd ansible-deployment/
```







### Create an ansible.cfg file
```
vi ansible.cfg
# or:  cp /etc/ansible/ansible.cfg ./ansible.cfg

[defaults]
host_key_checking=false
inventory=hosts
log_path = ./ansible.log
#remote_user = cloud-user
```

### Create an hosts.ini file
```
vi hosts

content:


s01 ansible_ssh_host=viyaserver01 
s02 ansible_ssh_host=viyaserver02 casrole=primary_controller
s03 ansible_ssh_host=viyaserver03 casrole=worker
s04 ansible_ssh_host=viyaserver04 casrole=worker

[cas]
s02
s03
s04

[viya]
s01


```

### check Ansible Connectivity
```
ansible all -m ping
```


## extra exercise: rm /home/cloud-user/.ssh/id_rsa 


### Download GEL Add-on playbook
will come as a wget command from a central web server (like yumrepomirror)
- gel.custom-group-list.yml
- gel.custom-user-list.yml
- gel.custom-users-and-groups.yml
- gel.pre-dep.yml
- gel.proper.service.configuration.yml


```
ansible-playbook gel.pre-dep.yml
#ansible-playbook gel.custom-users-and-groups.yml
ansible-playbook multiple-machines.yml
```



``` 
customize the 3 files
```


### encrypting passwords: 
```
 sudo yum install -y python-passlib
 python -c "from passlib.hash import sha512_crypt; import getpass; print sha512_crypt.encrypt(getpass.getpass())"
```














# Troubleshooting
   home/cloud-user/.ansible
hanging
  run what ansible is trying to run. probably something stuck or asking a question. 
  yum is locked etc...



# Viya Deployment Process
## Create Order
## Read Documentation
## Receive SOE
## Upload SOE content to server
## Perform Pre-Reqs



[Book the deployed collection with VA 7.3 for 2 days](http://race.exnet.sas.com/Reservations.aspx?action=new&imageId=29094&imageKind=C&comment=DEPLOYED%20Viya%20Collection%20with%20VA%20and%20w20%20ML&purpose=P&schedtype=SchedTrainEDU&startDate=now&endDateLength=2)

