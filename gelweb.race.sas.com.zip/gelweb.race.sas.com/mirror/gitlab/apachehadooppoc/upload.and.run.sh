cd /drives/c/_RPO/SAS/GEL/GEL\ PROJECTS/AnsiblePocToolbox/hadooppoc

export ANSIBLEHOST=pdcesx08006.race.sas.com
#with root account:
#export SUDOUSER=root
#ssh  $SUDOUSER@$ANSIBLEHOST hostname
export SUDOUSER=cloud-user
export SSHKEY=cloud-user/id_rsa

# with cloud-user: 
# as root allow further sudo commands from ssh for cloud-user account
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST hostname
ssh root@$ANSIBLEHOST cp /etc/sudoers /etc/sudoers.backup
ssh root@$ANSIBLEHOST "echo Defaults:cloud-user \!requiretty >> /etc/sudoers"
# note : if you don't have root password, 
# just add "echo Defaults:cloud-user !requiretty" in /etc/sudoers using sudo visudo -f /etc/sudoers

#scp  -i $SSHKEY  $SSHKEY    $SUDOUSER@$ANSIBLEHOST:/home/ec2-user/.ssh/id_rsa
#ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "chmod 600 /home/ec2-user/.ssh/id_rsa"
 
# install ansible & required modules

# with root: 
#ssh  $SUDOUSER@$ANSIBLEHOST yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm -y
#ssh  $SUDOUSER@$ANSIBLEHOST yum install ansible python-pip -y

# with clouduser: 

ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST sudo yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm -y
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST sudo yum install ansible python-pip -y

## rsync the local content up
#with root
#cd /drives/c/_RPO/SAS/GEL/GEL\ PROJECTS/AnsiblePocToolbox/hadooppoc
#ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST mkdir /root/hadooppoc
#rsync -e "ssh " --exclude='.git/' -avz . $SUDOUSER@$ANSIBLEHOST:/root/hadooppoc/

#with cloud-user
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST mkdir /home/cloud-user/hadooppoc
rsync -e "ssh -i $SSHKEY" --exclude='.git/' -avz . $SUDOUSER@$ANSIBLEHOST:/home/cloud-user/hadooppoc/

#fix etc/host in RACE env
# stress the fact that you need to look at /etc/host file and pick the proper machine name for inventory
#as it will be used for kerberos host principal creation.

# as root
#ssh  $SUDOUSER@$ANSIBLEHOST chmod a+x /root/hadooppoc/HostfileUpdate.sh
#ssh  $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible localhost -m shell -a \"cp /etc/hosts /etc/hosts.backup\" -b"
#ssh  $SUDOUSER@$ANSIBLEHOST /root/hadooppoc/HostfileUpdate.sh 
#ssh  $SUDOUSER@$ANSIBLEHOST cat /etc/hosts
# UPDATE AND UPLOAD INVENTORY FILE BEFORE RUNNING THE LINES BELOW !!!
#ssh  $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible all -m shell -a \"cp /etc/hosts /etc/hosts.backup\" -b"
#ssh  $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible all -m copy -a \"src=/etc/hosts dest=/etc/hosts remote_src=False mode=0644 owner=root group=root\" -b"    

# as cloud-user
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST chmod a+x hadooppoc/HostfileUpdate.sh
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/cloud-user/hadooppoc;ansible localhost -m shell -a \"cp /etc/hosts /etc/hosts.backup\" -b"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/cloud-user/hadooppoc; sudo ./HostfileUpdate.sh" 
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST cat /etc/hosts
# UPDATE AND UPLOAD INVENTORY FILE BEFORE RUNNING THE LINES BELOW !!!
#ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/cloud-user/hadooppoc;ansible all -m shell -a \"cp /etc/hosts /etc/hosts.backup\" -b"
#ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/cloud-user/hadooppoc;ansible all -m copy -a \"src=/etc/hosts dest=/etc/hosts remote_src=False mode=0644 owner=root group=root\" -b"

# Check ansible ping 
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/cloud-user/hadooppoc;ansible -m ping all"

#Run the playbook
#ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/cloud-user/hadooppoc;sudo ansible-playbook gel.hadoopsetup.yml"


# Hadoop check:
export HADOOPNN=pdcesx08006.race.sas.com
ssh -i $SSHKEY hdfs@$ANSIBLEHOST

[hdfs@pdcesx08006 ~]$ /usr/local/hadoop/sbin/slaves.sh hostname
[hdfs@pdcesx08006 ~]$ hdfs namenode -format
[hdfs@pdcesx08006 ~]$ /usr/local/hadoop/sbin/start-dfs.sh
[hdfs@pdcesx08006 ~]$ /usr/local/hadoop/sbin/start-yarn.sh


# check hadoop process
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/cloud-user/hadooppoc;ansible all -m shell -a \"ps -ef | grep hadoop\" -b"









#rsync and validate
rsync -e "ssh " --exclude='.git/' -avz . $SUDOUSER@$ANSIBLEHOST:/root/hadooppoc/ ; ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/ ; ls -al "
rsync -e "ssh " --exclude='.git/' -avz . $SUDOUSER@$ANSIBLEHOST:/root/hadooppoc/ ; ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/ ; ansible all -m ping"
rsync -e "ssh " --exclude='.git/' -avz . $SUDOUSER@$ANSIBLEHOST:/root/hadooppoc/ ; ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/ ; ansible-playbook gel.01.kdcldapserv.yml --list-tasks"

#ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.01.kdcldapserv.yml --step --tags \"prereqs\""
#ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.01.kdcldapserv.yml --step --tags \"ldap\""
# check steps
# test on kdcserver host with:

# admin/admin, http://ansible_fqdn:9830
#ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.01.kdcldapserv.yml --step --tags \"kerberos\""
#ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.01.kdcldapserv.yml --step --tags \"sssd\""
#ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.01.kdcldapserv.yml --step --tags \"addusers\""

#ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.01.kdcldapserv.yml --step --tags \"addusers\""


#ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.02.kdcclient.yml --step"

#ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.03.registerkdcclienthosts.yml --step"

ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.securehadoop.yml --tags \"prereqs\"" 
ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.securehadoop.yml --tags \"ldap\""
# ldapsearch -x -b "dc=gelhpr,dc=com"
export KDCLDAPHOST=pdcesx08023.race.sas.com
ssh $SUDOUSER@$KDCLDAPHOST "ldapsearch -x -b \"dc=gelhpr,dc=com\""
# test with 389-console 
ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.securehadoop.yml --tags \"kerberos\"" 
ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.securehadoop.yml --tags \"sssd\"" 
ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.securehadoop.yml --tags \"addusers\"" 
ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.securehadoop.yml --tags \"finalize\"" 

ssh $SUDOUSER@$ANSIBLEHOST "cd /root/hadooppoc/;ansible-playbook gel.securehadoop.yml --tags \"hadooppreqs\""


# kerberos check:
# check passwordless ssh and homefolder creation
# generate a ticket and ssh with "-v" from kdc server to other nodes
# keytabs: 
# ansible all -m shell -a "klist -e -k -t /etc/krb5.keytab" -b
# check the kvno

#Hadoop test
# preqreqs : check you can ssh from nn to dn 
# with hdfs and root account without being prompted

#sudo su - hdfs
#hdfs namenode -format
#/usr/local/hadoop/sbin/start-dfs.sh
# needs to run as root : 
#/usr/local/hadoop/sbin/start-secure-dns.sh
#hdfs dfsadmin -report
#/usr/local/hadoop/sbin/start-yarn.sh
#/usr/local/hadoop/sbin/stop-dfs.sh
#/usr/local/hadoop/sbin/stop-yarn.sh
#$HADOOP_HOME/sbin/slaves.sh jps
#hadoop jar /usr/local/hadoop/share/hadoop/mapreduce/hadoop-mapreduce-examples-2.7.2.jar pi 10 30
