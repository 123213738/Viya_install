cd /drives/c/_RPO/SAS/GEL/GEL\ PROJECTS/AnsiblePocToolbox/securehadooppoc
export ANSIBLEHOST=10.249.18.245

# allow ssh sudo:
# check/add "echo Defaults:cloud-user !requiretty" in /etc/sudoers using sudo visudo -f /etc/sudoers
export SUDOUSER=ec2-user
export SSHKEY=ec2-user/securehadoop.pem

# TODO FIRST
#[frarpo.frarpo01] ➤ ssh -i ec2-user/securehadoop.pem ec2-user@10.249.18.245
#sudo visudo -f /etc/sudoers
#then add Defaults:ec2-user !requiretty at the end

ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "echo 'HOSTNAME=mysh3.aws.sas.com' | sudo tee --append /etc/sysconfig/network"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "echo 'mysh3.aws.sas.com' | sudo tee /etc/hostname"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "echo 'preserve_hostname: true' | sudo tee --append /etc/cloud/cloud.cfg"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "sudo reboot"

# get IPs from teh EC2 console and prepare the /etc/hosts like
10.249.18.161 mysh1.aws.sas.com mysh1
10.249.18.140 mysh2.aws.sas.com mysh2
10.249.18.245 mysh3.aws.sas.com mysh3
10.249.19.169 mysh4.aws.sas.com mysh4

# log on all other EC2 IPs
# ssh -i ec2-user/securehadoop.pem ec2-user@????
# and run the commands
echo 'HOSTNAME=mysh1.aws.sas.com' | sudo tee --append /etc/sysconfig/network
echo 'mysh1.aws.sas.com' | sudo tee /etc/hostname
echo 'preserve_hostname: true' | sudo tee --append /etc/cloud/cloud.cfg
sudo reboot;exit

echo 'HOSTNAME=mysh2.aws.sas.com' | sudo tee --append /etc/sysconfig/network
echo 'mysh2.aws.sas.com' | sudo tee /etc/hostname
echo 'preserve_hostname: true' | sudo tee --append /etc/cloud/cloud.cfg
sudo reboot;exit

echo 'HOSTNAME=mysh4.aws.sas.com' | sudo tee --append /etc/sysconfig/network
echo 'mysh4.aws.sas.com' | sudo tee /etc/hostname
echo 'preserve_hostname: true' | sudo tee --append /etc/cloud/cloud.cfg
sudo reboot;exit


# Configure ssh passwordless key for ec2-user
scp -i $SSHKEY $SSHKEY $SUDOUSER@$ANSIBLEHOST:/home/ec2-user/.ssh/
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "chmod 600 /home/ec2-user/.ssh/securehadoop.pem"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "ssh-keygen -q -t rsa -b 1024 -N '' -f .ssh/id_rsa"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cat /home/ec2-user/.ssh/id_rsa.pub >> /home/ec2-user/.ssh/authorized_keys"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "scp -o StrictHostKeyChecking=no -i ~/.ssh/securehadoop.pem -r /home/ec2-user/.ssh/id_rsa.pub mysh1.aws.sas.com:/tmp"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "scp -o StrictHostKeyChecking=no -i ~/.ssh/securehadoop.pem -r /home/ec2-user/.ssh/id_rsa.pub mysh2.aws.sas.com:/tmp"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "scp -o StrictHostKeyChecking=no -i ~/.ssh/securehadoop.pem -r /home/ec2-user/.ssh/id_rsa.pub mysh4.aws.sas.com:/tmp"
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "ssh -o StrictHostKeyChecking=no -i ~/.ssh/securehadoop.pem mysh1.aws.sas.com \"cat /tmp/id_rsa.pub >> /home/ec2-user/.ssh/authorized_keys\"" 
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "ssh -o StrictHostKeyChecking=no -i ~/.ssh/securehadoop.pem mysh2.aws.sas.com \"cat /tmp/id_rsa.pub >> /home/ec2-user/.ssh/authorized_keys\"" 
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "ssh -o StrictHostKeyChecking=no -i ~/.ssh/securehadoop.pem mysh4.aws.sas.com \"cat /tmp/id_rsa.pub >> /home/ec2-user/.ssh/authorized_keys\"" 

# install ansible & required modules
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST sudo yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm -y
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST sudo yum install ansible python-pip -y

## rsync the local content up
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST mkdir /home/ec2-user/securehadooppoc
rsync -e "ssh -i $SSHKEY" --exclude='.git/' -avz . $SUDOUSER@$ANSIBLEHOST:/home/ec2-user/securehadooppoc/

#Distribute the etc/hosts file
# UPDATE AND UPLOAD INVENTORY FILE BEFORE RUNNING THE LINES BELOW !!!
#ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cp /home/ec2-user/securehadooppoc/inventory.ini.AWS /home/ec2-user/securehadooppoc/inventory.ini" 
#ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/ec2-user/securehadooppoc;sudo ansible all -m shell -a \"cp /etc/hosts /etc/hosts.backup\" -b"
#ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/ec2-user/securehadooppoc;sudo ansible all -m copy -a \"src=/etc/hosts dest=/etc/hosts remote_src=False mode=0644 owner=root group=root\" -b"

# check ansible ping
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/ec2-user/securehadooppoc;sudo ansible -m ping all"
# Check the playbook
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/ec2-user/securehadooppoc;sudo ansible-playbook gel.securehadoop.yml --list-tasks"
#Run the playbook
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "cd /home/ec2-user/securehadooppoc;sudo ansible-playbook gel.securehadoop.yml"

# validate Hadoop
[frarpo.frarpo01] ➤ ssh -i ec2-user/securehadoop.pem ec2-user@10.249.18.245
[ec2-user@mysh3 ~]$ kinit hdfs
[ec2-user@mysh3 ~]$ ssh hdfs@mysh1.aws.sas.com
[hdfs@mysh1 ~]$ /usr/local/hadoop/sbin/slaves.sh hostname
mysh3.aws.sas.com: Warning: Permanently added 'mysh3.aws.sas.com,10.249.18.245' (ECDSA) to the list of known hosts.
mysh4.aws.sas.com: Warning: Permanently added 'mysh4.aws.sas.com,10.249.19.169' (ECDSA) to the list of known hosts.
mysh2.aws.sas.com: Warning: Permanently added 'mysh2.aws.sas.com,10.249.18.140' (ECDSA) to the list of known hosts.
mysh4.aws.sas.com: mysh4.aws.sas.com
mysh2.aws.sas.com: mysh2.aws.sas.com
mysh3.aws.sas.com: mysh3.aws.sas.com

[hdfs@mysh1 ~]$ hdfs namenode -format
[hdfs@mysh1 ~]$ /usr/local/hadoop/sbin/start-dfs.sh
[hdfs@mysh1 ~]$ exit

[ec2-user@mysh3 ~]$ ssh mysh1
[ec2-user@mysh1 ~]$ sudo su -
[root@mysh1 ~]# /usr/local/hadoop/sbin/start-secure-dns.sh
[root@mysh1 ~]# exit

[ec2-user@mysh3 ~]$ ssh hdfs@mysh1.aws.sas.com hdfs dfsadmin -report

#test with HDFS UI
[ec2-user@mysh1 ~]$ sudo yum install libXext.x86_64 libXp.x86_64 libXtst.x86_64 xorg-x11-xauth.x86_64 xorg-x11-apps libuuid libSM libXrender fontconfig libstdc++ -y
[ec2-user@mysh1 ~]$ sudo systemctl restart sshd
[ec2-user@mysh3 ~]$ sudo yum install firefox -y
[ec2-user@mysh3 ~]$ firefox https://mysh1.aws.sas.com:50470

# status of hadoop services
ssh -i $SSHKEY $SUDOUSER@$ANSIBLEHOST "ssh hdfs@mysh1.aws.sas.com /usr/local/hadoop/sbin/slaves.sh jps"





