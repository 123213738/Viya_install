#!/bin/bash

# Specific to RACE environment : prepare a cleaner hosts file including the hostname fqdn
# General Variables
tmpFile=/tmp/tmpHosts
ArrayGateSH=("viyaserver01" "viyaserver02" "viyaserver03" "viyaserver04")
ArrayGateFQH=("viyaserver01.gelhpr.com" "viyaserver02.gelhpr.com" "viyaserver03.gelhpr.com" "viyaserver04.gelhpr.com")
# Number of lines in /etc/hosts
orgSize=9
newSize=6

function myFileCheck()
{
  # Check to see if SIMS has updated the /etc/hosts file
  FILENAME="/etc/hosts"
  FILESIZE=1
  while [ $FILESIZE -lt ${orgSize} ]; do
    echo "Checking for number of lines to be ${orgSize}..."
    FILESIZE=$(wc -l <"$FILENAME")
    if [ $FILESIZE == ${newSize} ]; then
      echo "File already updated, nothing to do"
      return 1
    fi
    sleep 10
  done
  echo "SIMS updated /etc/hosts file"
  return 0
}

function myUpdateFile()
{
# Variables for update
CurrentIP=`hostname -I|sed 's/.$//'`
CurrentFQH=`nslookup ${CurrentIP} |grep pdc|sed 's/.* //'|sed 's/.$//'`
CurrentSH=`echo ${CurrentFQH}|sed 's/.race.sas.com//'`
CurrentSIMS=`hostname -a|awk '{ print $2}'`
CurrentSIMS2=`getent hosts ${CurrentFQH}|awk '{print $4}'`
ArrayNTier=()
ArrayNTier+=(`getent hosts ${ArrayGateSH[0]}|awk '{ print $NF }'|sed -n '1{p;q}'`)
ArrayNTier+=(`getent hosts ${ArrayGateSH[1]}|awk '{ print $NF }'|sed -n '1{p;q}'`)
ArrayNTier+=(`getent hosts ${ArrayGateSH[2]}|awk '{ print $NF }'|sed -n '1{p;q}'`)
ArrayNTier+=(`getent hosts ${ArrayGateSH[3]}|awk '{ print $NF }'|sed -n '1{p;q}'`)
ArrayNTier+=(`getent hosts ${ArrayGateSH[4]}|awk '{ print $NF }'|sed -n '1{p;q}'`)
ArrayIP=()
ArrayIP+=(`getent hosts ${ArrayGateSH[0]}|awk '{ print $1 }'|sed -n '1{p;q}'`)
ArrayIP+=(`getent hosts ${ArrayGateSH[1]}|awk '{ print $1 }'|sed -n '1{p;q}'`)
ArrayIP+=(`getent hosts ${ArrayGateSH[2]}|awk '{ print $1 }'|sed -n '1{p;q}'`)
ArrayIP+=(`getent hosts ${ArrayGateSH[3]}|awk '{ print $1 }'|sed -n '1{p;q}'`)
ArrayIP+=(`getent hosts ${ArrayGateSH[4]}|awk '{ print $1 }'|sed -n '1{p;q}'`)

# Current host line
CurrentLine=${CurrentIP}
CurrentLine+=" "${CurrentFQH}
CurrentLine+=" "${CurrentSH}
CurrentLine+=" "${CurrentSIMS}
#ArrayCurrentLine=(${CurrentLine})

# Add localhost line to temp file
echo "127.0.0.1       localhost.localdomain   localhost" > ${tmpFile}

# Loop to add further lines
i="0"
while [[ $i -lt "${#ArrayIP[@]}" ]] ; do
      if [ "${CurrentIP}" = "${ArrayIP[$i]}" ]; then
            tmpFQH=`nslookup ${ArrayIP[$i]} |tail -2|head -1|awk '{print $4}'|head -c-2`
            tmpSH="${tmpFQH/.*}"
            NewLine=""
            NewLine=${ArrayIP[$i]}
            #rpo hack set pcdesx FQDN first to match Kerberos principal
            NewLine+=" "${tmpFQH}
            NewLine+=" "${tmpSH}                        
            NewLine+=" "${ArrayGateFQH[$i]}
            NewLine+=" "${ArrayGateSH[$i]}
            NewLine+=" "${ArrayNTier[$i]}
            NewLine+=" "${CurrentSIMS}
            NewLine+=" "${CurrentSIMS2}
            echo ${NewLine} >> ${tmpFile}
      else
            tmpFQH=`nslookup ${ArrayIP[$i]} |tail -2|head -1|awk '{print $4}'|head -c-2`
            tmpSH="${tmpFQH/.*}"
            NewLine=""
            NewLine=${ArrayIP[$i]}
            #rpo hack set pcdesx FQDN first to match Kerberos principal
            NewLine+=" "${tmpFQH}
            NewLine+=" "${tmpSH} 
            NewLine+=" "${ArrayGateFQH[$i]}
            NewLine+=" "${ArrayGateSH[$i]}                       
            NewLine+=" "${ArrayNTier[$i]}
            echo ${NewLine} >> ${tmpFile}
      fi
      let i++
done
myBK=/root/BackupHosts_$(date -d "today" +"%Y%m%d%H%M")
cp /etc/hosts ${myBK}
mv ${tmpFile} /etc/hosts
}

if myFileCheck; then
  myUpdateFile
fi
